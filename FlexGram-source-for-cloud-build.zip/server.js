require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const TelegramBot = require("node-telegram-bot-api");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = Number(process.env.PORT || 3000);
const OTP_TTL_SECONDS = Math.max(60, Number(process.env.OTP_TTL_SECONDS || 300));
const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID;

let bot = null;
if (BOT_TOKEN) {
  bot = new TelegramBot(BOT_TOKEN, { polling: true });
  bot.onText(/\/start/, (msg) => {
    bot.sendMessage(msg.chat.id,
      "FlexGram Auth Bot подключён. Этот бот отправляет только уведомления о регистрации FlexGram.");
  });
  bot.on("polling_error", (err) => console.error("Telegram polling error:", err.message));
} else {
  console.warn("BOT_TOKEN is not configured; Telegram notifications are disabled.");
}

// Demo storage only. Replace with a database before deploying publicly.
const pending = new Map();
const users = new Map();

function randomDigits(n) {
  return Array.from({ length: n }, () => crypto.randomInt(0, 10)).join("");
}
function makeVirtualNumber() {
  return `+888 ${randomDigits(4)} ${randomDigits(4)}`;
}
function makeUserId() {
  return `flex_${randomDigits(6)}`;
}
function hashCode(code, salt) {
  return crypto.createHash("sha256").update(`${salt}:${code}`).digest("hex");
}

app.post("/api/register/start", async (req, res) => {
  const name = String(req.body?.name || "").trim().slice(0, 32);
  if (!name) return res.status(400).json({ error: "Введите имя." });

  const virtualNumber = makeVirtualNumber();
  const userId = makeUserId();
  const code = randomDigits(6);
  const salt = crypto.randomBytes(16).toString("hex");

  pending.set(userId, {
    name, virtualNumber, salt, codeHash: hashCode(code, salt),
    expiresAt: Date.now() + OTP_TTL_SECONDS * 1000,
    attempts: 0
  });

  // Never send the verification code to an administrator. Admin gets a notification only.
  if (bot && ADMIN_CHAT_ID) {
    try {
      await bot.sendMessage(ADMIN_CHAT_ID,
        `🆕 Новая регистрация FlexGram\nИмя: ${name}\nID: ${userId}\nВиртуальный номер: ${virtualNumber}\nКод пользователю не раскрывается.`);
    } catch (err) {
      console.error("Could not notify admin:", err.message);
    }
  }

  // Development mode: code is shown in the server console only.
  // For production, deliver OTP to a verified user-controlled channel.
  if (process.env.NODE_ENV !== "production") {
    console.log(`[DEV ONLY] FlexGram verification code for ${userId}: ${code}`);
  }

  res.json({
    userId,
    virtualNumber,
    message: process.env.NODE_ENV === "production"
      ? "Запрос создан. Подключите подтверждённый канал доставки кода."
      : "Демо-режим: код напечатан в консоли сервера."
  });
});

app.post("/api/register/verify", (req, res) => {
  const userId = String(req.body?.userId || "");
  const code = String(req.body?.code || "").replace(/\D/g, "");
  const record = pending.get(userId);

  if (!record) return res.status(400).json({ error: "Запрос не найден. Начните регистрацию заново." });
  if (Date.now() > record.expiresAt) {
    pending.delete(userId);
    return res.status(400).json({ error: "Код истёк. Начните регистрацию заново." });
  }
  if (record.attempts >= 5) {
    pending.delete(userId);
    return res.status(429).json({ error: "Слишком много попыток. Начните заново." });
  }
  record.attempts += 1;
  if (hashCode(code, record.salt) !== record.codeHash) {
    return res.status(400).json({ error: "Неверный код." });
  }

  const user = {
    id: userId,
    name: record.name,
    virtualNumber: record.virtualNumber,
    createdAt: new Date().toISOString()
  };
  users.set(userId, user);
  pending.delete(userId);
  res.json({ ok: true, user });
});

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "FlexGram" }));

app.listen(PORT, () => console.log(`FlexGram running at http://localhost:${PORT}`));
