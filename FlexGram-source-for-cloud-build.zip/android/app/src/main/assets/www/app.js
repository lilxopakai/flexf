const $ = id => document.getElementById(id);
const stateKey = "flexgram_demo_state_v1";
let state = JSON.parse(localStorage.getItem(stateKey) || "null");
let currentTab = "chats", currentContact = "FlexGram Support";
const save = () => localStorage.setItem(stateKey, JSON.stringify(state));
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const num = n => Number(n).toLocaleString("ru-RU");
function showApp(){
  $("auth").hidden=true; $("app").hidden=false;
  $("profileName").textContent=state.name; $("profileId").textContent="@"+state.id;
  render();
}
$("startForm").addEventListener("submit", e=>{
  e.preventDefault(); const name=$("name").value.trim(); if(!name)return;
  const digits=()=>Array.from({length:4},()=>Math.floor(Math.random()*10)).join("");
  state={name,id:"flex_"+Math.floor(100000+Math.random()*900000),number:"+888 "+digits()+" "+digits(),
    stars:100,ton:0,gifts:[],nfts:[],contacts:["FlexGram Support"],messages:{"FlexGram Support":[{text:"Добро пожаловать в FlexGram! Это локальный прототип.",mine:false,at:new Date().toLocaleTimeString()}]}};
  save(); $("virtualNumber").textContent=state.number;
  $("startInfo").hidden=false; $("startInfo").textContent="Демо-код: 246810. В этой сборке подтверждение локальное; Telegram-бот не отправляет коды.";
  $("startForm").hidden=true; $("verifyForm").hidden=false;
});
$("verifyForm").addEventListener("submit",e=>{
  e.preventDefault(); if($("code").value.trim()!=="246810"){ $("error").textContent="Для демо введите код 246810."; return; }
  $("error").textContent=""; showApp();
});
document.querySelectorAll(".nav").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));b.classList.add("active");currentTab=b.dataset.tab;render();
}));
function header(title,sub){$("sectionTitle").textContent=title;$("sectionSubtitle").textContent=sub;}
function panel(title,sub,body){return `<div class="panel"><h2>${title}</h2><p class="sub">${sub}</p>${body}</div>`;}
function render(){
  if(!state)return;
  const v=$("view");
  if(currentTab==="chats"){
    header("Чаты","Сообщения сохраняются на этом устройстве");
    const chats=Object.keys(state.messages);
    v.innerHTML=panel("Твои чаты","Локальные переписки — сообщения доступны только в этой демоверсии.",`
      <div class="row"><input id="newChat" placeholder="Имя нового собеседника"><button class="action" id="addChat">Создать чат</button></div>
      <div class="list" style="margin-top:14px">${chats.map(c=>`<button class="item chatpick" data-chat="${esc(c)}"><span>💬 <b>${esc(c)}</b><small>${esc((state.messages[c].slice(-1)[0]||{}).text||"Нет сообщений")}</small></span><span class="tag">Открыть</span></button>`).join("")}</div>
      <div id="chatbox"></div>`);
    $("addChat").onclick=()=>{let n=$("newChat").value.trim();if(!n)return;if(!state.messages[n])state.messages[n]=[];if(!state.contacts.includes(n))state.contacts.push(n);save();render();};
    document.querySelectorAll(".chatpick").forEach(b=>b.onclick=()=>{currentContact=b.dataset.chat;renderChat();});
    if(!state.messages[currentContact])currentContact=chats[0]||"";
    if(currentContact)renderChat();
  } else if(currentTab==="contacts"){
    header("Контакты","Контакты этого демонстрационного аккаунта");
    v.innerHTML=panel("Контакты","Создай контакт — затем открой чат во вкладке «Чаты».",`<div class="row"><input id="contactName" placeholder="Имя пользователя"><button class="action" id="addContact">Добавить</button></div><div class="list" style="margin-top:14px">${state.contacts.map(c=>`<div class="item"><b>♙ ${esc(c)}</b><span class="tag">FlexGram</span></div>`).join("")}</div>`);
    $("addContact").onclick=()=>{let n=$("contactName").value.trim();if(n&&!state.contacts.includes(n)){state.contacts.push(n);state.messages[n]=state.messages[n]||[];save();render();}};
  } else if(currentTab==="gifts"){
    header("Подарки","Внутренняя коллекция демонстрационных подарков");
    const gifts=[["🌹","Роза",25],["🎂","Торт",75],["🚀","Ракета",150],["💎","Кристалл",300]];
    v.innerHTML=panel("Витрина подарков","Подарки списывают демо-Stars и добавляются в твою коллекцию. Реальной покупки нет.",`<div class="balance">★ ${num(state.stars)} <small>Stars</small></div><div class="grid">${gifts.map((g,i)=>`<div class="tile"><div class="emoji">${g[0]}</div><b>${g[1]}</b><small>${g[2]} демо-Stars</small><button class="action buygift" data-i="${i}">Подарить</button></div>`).join("")}</div><h3>Моя коллекция</h3><div class="list">${state.gifts.length?state.gifts.map(g=>`<div class="item"><b>${g.emoji} ${esc(g.name)}</b><small>Получено локально</small></div>`).join(""):"<p class='sub'>Пока подарков нет.</p>"}</div>`);
    document.querySelectorAll(".buygift").forEach(b=>b.onclick=()=>{let g=gifts[+b.dataset.i];if(state.stars<g[2])return alert("Недостаточно демо-Stars.");state.stars-=g[2];state.gifts.push({emoji:g[0],name:g[1]});save();render();});
  } else if(currentTab==="nft"){
    header("NFT","Демо-коллекция без блокчейн-транзакций");
    const nfts=[["🪐","Orbit #001","Уникальный цифровой предмет"],["🦊","Fox #014","Коллекционный предмет"],["🌌","Galaxy #007","Космическая серия"]];
    v.innerHTML=panel("Коллекция NFT","Можно добавлять предметы в локальную коллекцию. Это не настоящие NFT и не запись в блокчейне.",`<div class="grid">${nfts.map((n,i)=>`<div class="tile"><div class="emoji">${n[0]}</div><b>${n[1]}</b><small>${n[2]}</small><button class="soft addnft" data-i="${i}">Добавить в коллекцию</button></div>`).join("")}</div><h3>Мои NFT</h3><div class="list">${state.nfts.length?state.nfts.map(n=>`<div class="item"><b>${n.emoji} ${esc(n.name)}</b><span class="tag">DEMO</span></div>`).join(""):"<p class='sub'>Коллекция пока пуста.</p>"}</div>`);
    document.querySelectorAll(".addnft").forEach(b=>b.onclick=()=>{let n=nfts[+b.dataset.i];if(!state.nfts.some(x=>x.name===n[1]))state.nfts.push({emoji:n[0],name:n[1]});save();render();});
  } else if(currentTab==="stars"){
    header("Stars","Демонстрационный внутренний баланс");
    v.innerHTML=panel("Твой баланс Stars","Это тестовые баллы внутри приложения. Они не являются Telegram Stars и не имеют денежной стоимости.",`<div class="balance">★ ${num(state.stars)}</div><div class="row"><button class="action" id="earn">Начислить 10 демо-Stars</button><button class="soft" id="spend">Потратить 10</button></div><p id="starsMsg" class="success"></p>`);
    $("earn").onclick=()=>{state.stars+=10;save();render();};$("spend").onclick=()=>{if(state.stars>=10)state.stars-=10;else $("starsMsg").textContent="Недостаточно баллов.";save();render();};
  } else if(currentTab==="ton"){
    header("TON","Информация о подключении кошелька");
    v.innerHTML=panel("TON Wallet","В этой сборке нет реального TON Connect и переводов. Не вводи seed-фразу или приватный ключ в FlexGram.",`<div class="balance">◈ ${state.ton.toFixed(2)} TON</div><div class="warn">Кошелёк не подключён. Для настоящей интеграции потребуется TON Connect, опубликованный HTTPS-домен и проверка транзакций в сети. Никогда не передавай приложению seed-фразу.</div><button class="action" id="tonInfo">Как подключить TON</button><p id="tonMsg" class="success"></p>`);
    $("tonInfo").onclick=()=>$("tonMsg").textContent="Следующий этап: интеграция TON Connect SDK и проверка транзакций через сервер.";
  } else if(currentTab==="profile"){
    header("Профиль","Настройки демонстрационного аккаунта");
    v.innerHTML=panel("Твой профиль","Аватар не используется, как ты и попросил.",`<div class="item"><span><small>Имя</small><b>${esc(state.name)}</b></span></div><div class="item"><span><small>FlexGram ID</small><b>@${esc(state.id)}</b></span></div><div class="item"><span><small>Виртуальный номер</small><b>${esc(state.number)}</b></span></div><button class="soft" id="reset" style="margin-top:16px">Выйти и очистить демо-аккаунт</button>`);
    $("reset").onclick=()=>{if(confirm("Удалить локальный демо-аккаунт?")){localStorage.removeItem(stateKey);location.reload();}};
  }
}
function renderChat(){
  const box=$("chatbox"); if(!box)return;
  const msgs=state.messages[currentContact]||[];
  box.innerHTML=`<h3>Чат: ${esc(currentContact)}</h3><div class="chatlog" id="chatlog">${msgs.map(m=>`<div class="msg ${m.mine?"mine":""}">${esc(m.text)}<small>${m.mine?"Ты":"Собеседник"} · ${esc(m.at)}</small></div>`).join("")}</div><div class="row"><input id="messageText" placeholder="Напиши сообщение..."><button class="action" id="sendMessage">Отправить</button></div>`;
  $("sendMessage").onclick=sendMessage;
  $("messageText").addEventListener("keydown",e=>{if(e.key==="Enter")sendMessage();});
  $("chatlog").scrollTop=$("chatlog").scrollHeight;
}
function sendMessage(){
  const input=$("messageText"),text=input.value.trim();if(!text)return;
  state.messages[currentContact].push({text,mine:true,at:new Date().toLocaleTimeString()});
  save();render();currentContact=currentContact;renderChat();
}
if(state)showApp();
