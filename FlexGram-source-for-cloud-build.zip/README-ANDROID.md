# FlexGram Android project

This is an Android Studio WebView project containing the expanded local prototype.

## Build an APK
1. Install Android Studio and Android SDK Platform 35.
2. Open this project folder in Android Studio (the folder containing `settings.gradle`).
3. Let Gradle sync; use JDK 17 or 21.
4. Select Build → Build Bundle(s) / APK(s) → Build APK(s).
5. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk` (Android Studio may place it under the project `android/` folder depending on which directory you opened).

## Scope
This package includes local demo chat, contacts, gift collection, demo NFT collection, demo Stars balance, profile, and a TON information screen. It is not an online multi-user messenger and it does not make real payments or blockchain transactions. Read `STATUS.txt`.

No APK binary is included: this environment has no Android SDK/Gradle build toolchain, so a signed/compiled Android package cannot be produced here. The source is ready to open and build in Android Studio.
